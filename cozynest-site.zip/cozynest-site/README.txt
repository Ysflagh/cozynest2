COZYNEST — SITE PACKAGE

What's included
- index.html: responsive CozyNest home & decor affiliate website.
- data/offers.json: sample offer based on the card you provided.
- assets/room-planner.jpg: clean product image for the sample offer.

IMPORTANT BEFORE PUBLISHING
1. Open data/offers.json.
2. Replace #REPLACE_WITH_YOUR_AFFILIATE_LINK with your real affiliate URL.
3. Replace the sample title, image, coupon, price, badge and category with your real offer details.
4. Add additional offers by copying an offer object inside the offers array. Categories supported: living, bedroom, kitchen, bath, walldecor, lighting, storage, outdoor.
5. Upload the whole folder (not just index.html) to your static hosting. The data/offers.json file must remain at that exact relative path.

Offer fields
- title (required): short offer title
- image (optional): relative path to the product/offer image
- category (required): one of the supported categories above
- link (required for live CTA): your affiliate URL
- badge (optional): e.g. FREE TO TRY or 30% OFF
- coupon (optional): coupon code
- price / oldPrice (optional): price strings, e.g. "$29.99"
- expires (optional): YYYY-MM-DD

The supplied offer is a demo, not a verified live deal. Verify the coupon, landing page and affiliate link before publishing.
